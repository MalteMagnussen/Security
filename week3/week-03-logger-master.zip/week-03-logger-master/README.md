# week-03 Logger
This is a *very* simple webserver which just logs all calls to a file. It is made for demonstration rather than production.
