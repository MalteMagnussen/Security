# A2 Demo

Start code for exercise given at cphbusiness.dk - computer science
